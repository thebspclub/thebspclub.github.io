#if !defined ( VIEWH )
#define VIEWH 
#pragma once

void V_StartPitchDrift( void );
void V_StopPitchDrift( void );

#endif // !VIEWH