Half-Life SDK2 Source Code Distribution
=======================================

This is a distribution of the Half-Life SDK2 source code from Valve Software.
By using this software, you agree to Valve's licence conditions (contained
in licence.txt). You can only redistribute this file as a whole.

This distribution has been compiled by Steve Cook for Shadowman's SDK2 Resources:
http://www.planethalflife.com/hlsdk2

