#if !defined( MD5H )
#define MD5H
#pragma once

int MD5_Hash_File(unsigned char digest[16], char *pszFileName );

#endif