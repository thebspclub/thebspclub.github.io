//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by smdlexp.rc
//
#define IDD_SMDLEXP_UI                  101
#define IDD_EXPORTOPTIONS               101
#define IDC_CHECK_SKELETAL              1000
#define IDC_CHECK_DEFORM                1001
#define IDC_CHECK_REFFRAME              1002
#define IDC_CHECK_PHYSIQUE              1003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
