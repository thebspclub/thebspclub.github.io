//========= Copyright � 1996-2002, Valve LLC, All rights reserved. ============
//
// Purpose: 
//
// $NoKeywords: $
//=============================================================================

#if !defined ( PROCINFOH )
#define PROCINFOH
#pragma once

int		PROC_GetSpeed( void );
int		PROC_IsMMX( void );

#endif // PROCINFOH
