### System Information

e.g. TrenchBroom V2.0.0-RC4 on Windows 10

### Expected Behavior

### Steps to Reproduce

### Crash Info

In the case of a crash, please upload the generated stack trace, log file, and map file along with this report.

Thank you very much!