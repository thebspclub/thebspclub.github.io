# Font Awesome Free 5.15.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License)

- ColorPreferences.svg (was solid/palette.svg)
- OmitFromExport_off.svg (was regular/circle.svg)
- OmitFromExport_on.svg (was regular/times-circle.svg)
- ResetTextureToWorld.svg (was solid/globe.svg)
